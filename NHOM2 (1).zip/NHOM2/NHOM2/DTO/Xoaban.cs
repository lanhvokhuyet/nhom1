﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NHOM2.DTO
{
    public class Xoaban
    {
        string maBan;

        public string MaBan
        {
            get { return maBan; }
            set { maBan = value; }
        }
        string tenBan;

        public string TenBan
        {
            get { return tenBan; }
            set { tenBan = value; }
        }
    }
}