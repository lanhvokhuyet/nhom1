﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace NHOM2
{
    public partial class ThemNV : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadDataToDropDownList();
            }
        }

        

        protected void btnThem_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                // Lấy các giá trị từ giao diện
                string manv = txtMaNV.Text;
                string hoten = txtHoTen.Text;
                string ngaysinh =txtNgaySinh.Text;
                string diachi = txtDiaChi.Text;
                string sdt = txtSDT.Text;
                bool gioitinh =
                Boolean.Parse(rdbGioiTinh.SelectedValue);
                string vitrilamviec = ddlVTLV.Text;
                
                DAO.UserDAO userDAO = new DAO.UserDAO();
                // Kiểm tra username này đã tồn tại trong CSDL chưa
                bool exist = userDAO.CheckID(manv);
                if (exist)
                {
                     lblThongBao.Text = "Mã nhân viên đã tồn tại";
                }
                else
                {
                    // Thực hiện ghi xuống CSDL
                    DTO.User user = new DTO.User()
                    {
                    Manv = manv,
                    Hoten = hoten,
                    Ngaysinh = ngaysinh,
                    Gioitinh = gioitinh,
                    Sdt = sdt,
                    Diachi = diachi,
                    Vitrilamviec = vitrilamviec
                };
                bool result = userDAO.InsertNV(user);
                if (result)
                {
                    lblThongBao.Text = "Thêm nhân viên thành công!";
                }
                else
                {
                    lblThongBao.Text = "Có lỗi. Vui lòng thử lại sau";
                }
            }
}
        }
 
        private void LoadDataToDropDownList()
        {
            string connectionString = @"Data Source=MAYCHI\SQLEXPRESS;Initial Catalog=THLVN;Integrated Security=True";
            DataTable dataTable = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter("Select vitrilamviec From NHANVIEN", connectionString);
            adapter.Fill(dataTable);

            ddlVTLV.DataSource = dataTable;
            ddlVTLV.DataTextField = "vitrilamviec"; //Text hiển thị
            ddlVTLV.DataValueField = "vitrilamviec"; //Giá trị khi chọn
            ddlVTLV.DataBind();
        }

        protected void ddlVTLV_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void btnThoat_Click(object sender, EventArgs e)
        {
        }

    }
}