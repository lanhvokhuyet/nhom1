﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;

namespace NHOM2.DAO
{
    public class UserDAO
    {
        string connectionString =
        ConfigurationManager.ConnectionStrings["THLVN"].ConnectionString;

        public bool CheckID(string id)
        {
            string sql = @"SELECT COUNT(*) FROM NHANVIEN WHERE manv = @ma";
            using (SqlConnection connection =
            new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@ma", id);
                connection.Open();
                int count = (int)command.ExecuteScalar();
                return (count >= 1);
                //if (count >= 1) return true;
                //else return false;
            }
        }
        public bool InsertNV(DTO.User user)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = @"INSERT INTO NHANVIEN(manv,hoten,ngaysinh,gioitinh,sdt,diachi,vitrilamviec)
                            VALUES(@mnv,@ht,@ns,@gt,@dt,@dc,@vtlv)";
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("@mnv", user.Manv);
                cmd.Parameters.AddWithValue("@ht",user.Hoten);
                cmd.Parameters.AddWithValue("@ns",user.Ngaysinh);
                cmd.Parameters.AddWithValue("@gt",user.Gioitinh);
                cmd.Parameters.AddWithValue("@dt",user.Sdt);
                cmd.Parameters.AddWithValue("@dc",user.Diachi);
                cmd.Parameters.AddWithValue("@vtlv",user.Vitrilamviec);
                connection.Open();
                int result = cmd.ExecuteNonQuery();
                return (result >= 1);
            }
        }
    }

}